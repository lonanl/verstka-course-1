const stdBtn = { // exampleComponent - jsvascript-имя компонента
	name: 'std-btn', // example-comp - html-имя компонента,

	params: {
		'data-text': '$data-text$',
		'data-icon': '$data-icon$',
		'data-icon-has': '$data-icon-has$',
		'data-class': '$data-class$',
	},

	html:/*html*/`
		<button class="std-btn $data-class$">
				<span class="border"></span>
				<span class="content">
					<span>$data-text$</span>
					<span class="small-icon" 
						style="mask-image: url('/src/img/icons/$data-icon$'); 
						display: $data-icon-has$;
					"></span>
				</span>
		</button>
	`
}


const productCardMain = { // exampleComponent - jsvascript-имя компонента
	name: 'product-card-main', // example-comp - html-имя компонента,

	params: {
		'data-title': '$data-title$',
		'data-description': '$data-description$',
	},

	html:/*html*/`
							<div class="product-card">
                    <div class="top">
                        <h5>$data-title$</h5>
                        <img src="/src/img/products/piarat blend.jpg" alt="">
                        <p>$data-description$</p>
                    </div>
                    <div class="bottom">
                        <p class="regions">Эфиопия, Колумбия</p>
                        <div class="parametrs">
                            <div class="parametr-wrapper">
                                <p>
                                    Кислотность
                                </p>
                                <div class="parametr-value">
                                    <div class="parametr-value-red" style="width: 70%;"></div>
                                </div>
                            </div>
                            <div class="parametr-wrapper">
                                <p>
                                    Горечь
                                </p>
                                <div class="parametr-value">
                                    <div class="parametr-value-red" style="width: 35%;"></div>
                                </div>
                            </div>
                            <div class="parametr-wrapper">
                                <p>
                                    Плотность
                                </p>
                                <div class="parametr-value">
                                    <div class="parametr-value-red" style="width: 10%;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="weights">
                            <div>250гр</div>
                            <div>1кг</div>
                        </div>
                        <div class="prices">
                            <div>Цены:</div>
                            <div class="price left"><h5>685</h5></div>
                            <div class="price right"><h5>2450</h5></div>
                        </div>
                        <div class="actions">
                            <button class="icon-btn">
                                <span class="big-icon heart" style="mask-image: url('/src/img/icons/heart.svg');"></span>
                            </button>
                            <template name="std-btn" data-class="add" data-text="Добавить" data-icon="cart.svg"></template>
                        </div>
                    </div>
                </div>
	`
}



export const components = [stdBtn, productCardMain] // javascript-имена компонентов через запятую