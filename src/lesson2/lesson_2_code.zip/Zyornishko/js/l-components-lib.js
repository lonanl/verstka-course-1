import {components} from "/js/components.js"

function iteration() {
	const templatesEls = document.querySelectorAll('template[name]')
	for (const templateEl of templatesEls) {
		console.log('Добавляю компонент', templateEl)
		const component = components.find(component => component.name === templateEl.getAttribute('name'))
		let htmlString = component.html
		for (const paramName in component.params) {
			if (Object.prototype.hasOwnProperty.call(component.params, paramName)) {
				const searchTemplate = component.params[paramName];
				const paramValue = templateEl.getAttribute(paramName)
				while (htmlString.indexOf(searchTemplate) > - 1) {
					if (paramValue) {
						htmlString = htmlString.replace(searchTemplate, paramValue)
					}
					else {
						htmlString = htmlString.replace(searchTemplate, '')
					}
				}
			}
		}
		const element = new DOMParser().parseFromString(htmlString, 'text/html').body.firstChild
		templateEl.replaceWith(element)
		console.log('Добавлен компонент', element)
	}
}

function app() {
	iteration()
	const interval = setInterval(() => {
		if(document.querySelectorAll('template[name]')) {
			iteration()
		}
		else {
			clearInterval(interval)
			console.log('Все компоненты заполнены');
			
		}
	}, 50)
}

app()